# Architecture

## High-level

```
┌─────────────────────────────────────────────────────────────────────────┐
│                            Codeisa.exe (Tauri)                          │
│                                                                          │
│  ┌─────────────────────────────────────────┐  ┌──────────────────────┐  │
│  │  WebView2 (Chromium runtime)            │  │  Rust backend        │  │
│  │                                         │  │                      │  │
│  │  src/index.html                         │  │  lib.rs              │  │
│  │   ├─ Original Codeisa (untouched)       │  │   ├─ Splash mgmt     │  │
│  │   ├─ fluent-overlay.css   (additive)    │  │   ├─ System tray     │  │
│  │   ├─ i18n-runtime.js      (additive)    │  │   ├─ Notifications   │  │
│  │   ├─ calendar-pro.js      (additive)    │  │   ├─ Single-instance │  │
│  │   └─ Tauri JS bridge                    │◄─┼──┤  Window state      │  │
│  │                                         │  │   ├─ Auto-start      │  │
│  │  src/splash.html                        │  │   └─ Updater         │  │
│  │   └─ Animated startup screen            │  │                      │  │
│  └─────────────────────────────────────────┘  │  network.rs          │  │
│                                                │   └─ Native NIC poll │  │
│                                                └──────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
```

## Module map

### Frontend (web layer, all in `src/`)

| File | Lines | Purpose |
|---|---|---|
| `index.original.html` | 10,386 | **Pristine** copy of the original app. Never modified. |
| `index.html`          | 10,394 | Original + `<link>`/`<script>` injections in `<head>` and one `<div>` + script block at end of `<body>`. Every original ID, class, function, and event handler is intact. |
| `fluent-overlay.css`  | 90 | Win11 / Fluent polish. Only enhances existing card / button / input classes; no layout changes. |
| `i18n-runtime.js`     | 170 | Runtime FA↔EN overlay (see LOCALIZATION.md). |
| `calendar-pro.js`     | 350 | Triple calendar engine + holiday DB (see CALENDAR.md). |
| `splash.html`         | 70 | Animated splash screen. |
| `locales/{fa,en}.json` | varies | Translation tables (built from extractor). |

### Backend (Rust, `src-tauri/src/`)

| File | Purpose |
|---|---|
| `main.rs`     | Windows-subsystem entry point (no console window in release). |
| `lib.rs`      | Tauri builder: plugin registration, commands, tray, window events, splash lifecycle, autostart toggle. |
| `network.rs`  | sysinfo-based NIC counter poller with 500ms refresh, lock-free atomic snapshot. |

## IPC commands (Rust ↔ JS)

| Command | Direction | Purpose |
|---|---|---|
| `show_main_window`         | JS → Rust | Reveal the main window, close splash. |
| `register_global_state`    | JS → Rust | Sync user-selected language with backend. |
| `get_network_stats`        | JS → Rust | Pull a NetStats snapshot on demand. |
| `set_autostart`            | JS → Rust | Toggle "Start with Windows". |
| `notify`                   | JS → Rust | Show a native Windows notification. |
| `codeisa://network-stats`  | Rust → JS (event) | Per-second NIC delta. |
| `codeisa://set-language`   | Rust → JS (event) | Tray-driven language switch. |
| `codeisa://main-ready`     | JS → Rust (event) | Splash dismiss signal. |
| `codeisa://show-about`     | Rust → JS (event) | Tray → About. |

## Why this layered design

- **Preservation guarantee** — the original app sees no breaking changes. The runtime overlay can be disabled with a single boolean (`window.codeisaI18n = null;`) and the original app continues to work in pure Persian mode.
- **Re-runnable extractor** — translations are content-addressed by SHA-1 of the Persian source string. Re-running `npm run extract` after edits to `index.original.html` never destroys translations already filled in.
- **Single-process tray** — Tauri 2 runs the tray on the same event loop as the window; there is no auxiliary process, RAM stays low.
- **WebView2 only** — Tauri uses the system WebView2, so the binary doesn't bundle Chromium. Final installer is < 12 MB.
