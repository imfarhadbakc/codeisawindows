# Codeisa Desktop — Build Instructions

## TL;DR (Windows)

```powershell
# 1. Clone / unzip the project
# 2. From the repo root, in PowerShell:
powershell -ExecutionPolicy Bypass -File scripts\build.ps1
```

This single command:
* checks Node + Rust are installed,
* installs npm dependencies,
* compiles the Rust backend in release mode,
* bundles the **portable EXE**, **NSIS setup.exe**, and **MSI installer**,
* copies everything to `./dist/`.

### Final artifacts

| File | Description |
|---|---|
| `dist/Codeisa-Portable.exe` | Standalone portable executable (no installation) |
| `dist/Codeisa_1.0.0_x64-setup.exe` | NSIS installer (recommended for end users) |
| `dist/Codeisa_1.0.0_x64_en-US.msi` | MSI installer (enterprise / group-policy deployment) |

---

## Prerequisites

### 1. Node.js ≥ 18
Download from <https://nodejs.org/>. After install:
```powershell
node --version    # should print v18.x or v20.x
```

### 2. Rust (MSVC toolchain)
```powershell
# Install rustup
winget install Rustlang.Rustup
# Set MSVC toolchain as default
rustup default stable-x86_64-pc-windows-msvc
rustup target add x86_64-pc-windows-msvc
```

### 3. Visual Studio Build Tools 2019 or 2022
Tauri needs the MSVC linker and Windows SDK.
* Download: <https://visualstudio.microsoft.com/visual-cpp-build-tools/>
* Required workload: **Desktop development with C++** (includes Windows 11 SDK).

### 4. WebView2 Runtime
Pre-installed on Windows 10 1809+ and Windows 11. Older systems install it via the bootstrapper embedded in the installer (`webviewInstallMode = embedBootstrapper`).

---

## Manual build (without the helper script)

```powershell
npm install
npm run build              # builds both NSIS and MSI
# or
npm run build:nsis         # NSIS setup.exe only
npm run build:msi          # MSI only
```

Bundles end up under:
```
src-tauri/target/release/bundle/nsis/  → *-setup.exe
src-tauri/target/release/bundle/msi/   → *.msi
src-tauri/target/release/codeisa.exe   → portable EXE
```

---

## CI builds (recommended)

The repository ships a ready-made GitHub Actions workflow at `.github/workflows/windows-release.yml`. Push to `main` or tag a release (`v1.0.0`) and the workflow will:

1. Spin up a clean `windows-latest` runner.
2. Install Node + Rust + Tauri CLI.
3. Build the portable EXE, NSIS setup.exe, and MSI.
4. Upload them as a workflow artifact `codeisa-windows-x64`.
5. On a tag push, automatically attach the binaries to a GitHub Release.

This is the most reliable way to produce reproducible Windows builds and the path the Tauri team officially recommends.

---

## Cross-compile from Linux / macOS

Tauri does support cross-compilation to Windows from Linux via [`cargo-xwin`](https://github.com/rust-cross/cargo-xwin), but it requires:

* ≥ 4 GB RAM (rustc + linker)
* ~3 GB free disk (Windows SDK fetched by xwin)
* `nsis` package (for NSIS bundling) or `wine` (for MSI)

Minimal example:
```bash
rustup target add x86_64-pc-windows-msvc
cargo install cargo-xwin
sudo apt install nsis    # NSIS bundler

npm install
npx tauri build --runner cargo-xwin --target x86_64-pc-windows-msvc --bundles nsis
```

MSI from Linux is fragile — use the GitHub Actions workflow instead.

---

## Troubleshooting

### `link.exe not found`
Install Visual Studio Build Tools with the C++ workload (see Prerequisites #3).

### `webview2 not found` at runtime
The installer auto-installs WebView2 on first launch. If you ran the portable EXE on Windows 7/8 (unsupported), install <https://developer.microsoft.com/microsoft-edge/webview2/> manually.

### MSI fails: "Cannot find WiX"
Tauri auto-downloads WiX 3.x on first run. If your runner has no internet during build, pre-cache `~/AppData/Local/tauri` or use the `WIX_PATH` env var.

### Build is very slow
The default release profile uses full LTO + 1 codegen unit for smallest binary. To speed up iteration, set:
```powershell
$env:CARGO_PROFILE_RELEASE_LTO = "thin"
$env:CARGO_PROFILE_RELEASE_CODEGEN_UNITS = "4"
npm run build
```
This trims build time by ~50% with negligible binary-size impact.

### Code signing (optional)
For production, sign the EXE and installers to avoid SmartScreen warnings:
```powershell
signtool sign /fd SHA256 /a /tr http://timestamp.digicert.com /td SHA256 dist\*.exe dist\*.msi
```
You'll need a code-signing certificate (DigiCert, Sectigo, SSL.com, etc.).

---

## What was fixed in this build

Compared to the original project, the following was corrected to make a clean Windows release possible:

| Fix | File | Reason |
|---|---|---|
| Generated proper multi-resolution `icon.ico` (16/32/48/64/128/256) | `src-tauri/icons/icon.ico` | Original was 16×16 only — Windows shell rejects single-res ICOs in `.exe` resources |
| Generated full Tauri icon set (`Square*Logo.png`, `StoreLogo.png`) | `src-tauri/icons/*` | Required for MSI packaging |
| Removed dangling `"resources": ["resources/*"]` glob | `src-tauri/tauri.conf.json` | Folder was empty → glob matched 0 files → bundler error |
| Added stable WiX `upgradeCode` GUID | `src-tauri/tauri.conf.json` | Ensures future MSI upgrades replace the previous install |
| Added `nsis.compression: "lzma"` | `src-tauri/tauri.conf.json` | ~35% smaller setup.exe |
| Fixed `Networks::refresh(true)` → `refresh()` | `src-tauri/src/network.rs` | sysinfo 0.31 API mismatch (compile error) |
| Removed unused `use sysinfo::Networks` | `src-tauri/src/lib.rs` | Warning-free build |
| Added `quit_app` Tauri command | `src-tauri/src/lib.rs` | Frontend can request real exit (vs minimize-to-tray) |
| Disabled updater (`active: false`) | `src-tauri/src/lib.rs` & `tauri.conf.json` | Updater without `pubkey` blocks the bundler. Re-enable after `tauri signer generate`. |
| Added build script | `scripts/build.ps1` | One-command production build |
| Added CI workflow | `.github/workflows/windows-release.yml` | Reproducible cloud builds |
