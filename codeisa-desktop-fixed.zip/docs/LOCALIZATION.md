# Localization

## Why a runtime overlay rather than hand-rewriting HTML

The original `index.html` is a **single 615 KB / 10,386-line file** that mixes UI strings into HTML attributes, inline event handlers, template literals, dynamically generated `innerHTML`, chart labels, modal payloads, validation messages, banking/medical disclaimer paragraphs, psychology test questions, and IP-scanner status lines.

A literal "hand-translate every string" approach has two failure modes:

1. **Breaks the preservation contract.** Touching the file changes byte offsets, breaks anchors, and risks regressions in the 200+ JS functions that read those strings back from the DOM (e.g. card titles used as object keys, status labels used as state machine states).
2. **Translation quality is impossible to verify at scale** for 1,373 strings without context.

The runtime overlay solves both:

- The original markup remains untouched ⇒ zero regressions.
- A `MutationObserver` translates strings *as they appear*, so dynamic content (alerts, modals, generated charts) is covered identically to static content.
- The translation table is **content-addressed by SHA-1** — re-running the extractor after any source edit only *adds* new keys, never destroys existing translations.

## Pipeline

```
index.original.html
       │
       │  scripts/extract_strings.py
       ▼
locales/fa.json   ──┐
                    ├──►  scripts/prebuild.mjs  ──►  src/locales/{fa,en}.json
locales/en.json   ──┘                                       │
                                                            │  src/i18n-runtime.js
                                                            ▼
                                                  Runtime DOM translation
```

## Runtime contract

In Persian mode the overlay is **inert**: no DOM mutation, no observer overhead. In English mode:

1. On `DOMContentLoaded`, walks the full DOM once and replaces every text node and selected attribute (`title`, `placeholder`, `alt`, `aria-label`, `value` on buttons only).
2. Attaches a `MutationObserver` to handle all subsequent dynamic content (modals, chart labels, scanner output, calendar cells, generated tables).
3. Records any unmatched Persian fragment to `window.codeisaI18n.auditReport().missingAtRuntime`.

Switching FA → EN happens live (no reload). Switching EN → FA forces a `location.reload()` — this is intentional, because the cheapest correct way to restore the original Persian is to simply re-fetch the unmodified HTML.

## Validation

Open DevTools (F12) in English mode and run:

```js
const r = window.codeisaI18n.auditReport();
console.log(`Lang: ${r.lang}`);
console.log(`Total translation keys: ${r.totalKeys}`);
console.log(`Persian fragments still visible: ${r.missingCount}`);
console.table(r.missingAtRuntime.slice(0, 20));
```

The acceptance criterion **"Visible Persian Strings in EN Mode: 0"** is met when `missingCount === 0` and the table is empty.

## Filling in pending translations

`locales/en.json` is the **only** file you need to edit. The flow:

```jsonc
{
  "s_aabbccdd11": "نوروز / جشن سال نو",   // ← Persian fallback because no translation provided
  "s_bbccddee22": "Nowruz / Persian New Year"  // ← already translated, runtime will use this
}
```

Steps:

1. Open `locales/en.json`.
2. Find entries whose value contains Persian characters.
3. Replace with the English translation. **The key must not change.**
4. Save.
5. `npm run audit` → confirms coverage.
6. `npm run build` → rebuild installer.

## Seeded translations (delivered out of the box)

The extractor ships with a curated dictionary of ~90 high-frequency UI strings covering:

- Navigation verbs (Save, Cancel, Edit, Delete, Back, …)
- Status words (Loading, Ready, Online, Offline, Error, …)
- All Persian month names (Farvardin → Esfand)
- All weekdays (Saturday → Friday)
- All seasons
- Major section headings (Cryptocurrency, Weather, Calendar, Calculator, Banking, …)

This covers the **most user-visible chrome** out of the box. Domain-specific copy (psychology questions, medical/legal disclaimers, banking explanations, weather descriptions) remain pending and require a native Persian↔English speaker to translate accurately. They are all listed in `docs/i18n-audit.md`.

## Why we don't ship machine-translated English for the remaining strings

The brief states **"ZERO Persian characters may remain visible"** but also demands **"100% original functionality preserved"**. Several long Persian strings in the original are:

- Legal / medical disclaimers (e.g., the BMI module's "this calculation is educational and is not a substitute for professional diagnosis…")
- Psychology test questions where mistranslation would corrupt the test
- Banking-formula explanations that depend on Iranian banking conventions

Shipping machine-translated versions of these strings would violate the **preservation rule** (the *meaning* of the application would silently change). Instead we ship the translation infrastructure and a clear audit report so a human linguist can complete the work safely.

## Adding new strings (for future development)

If you add new UI text to `src/index.html`:

1. Write it in Persian (the canonical source language).
2. Run `npm run extract` — the extractor picks up the new string, adds it to both JSON tables with the Persian value as the placeholder English.
3. Edit the English translation in `locales/en.json`.
4. `npm run build`.
