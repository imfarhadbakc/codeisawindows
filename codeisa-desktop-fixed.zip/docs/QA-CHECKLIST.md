# QA Checklist

Manual smoke tests to run after `npm run build`.

## Installation
- [ ] MSI installs without UAC errors on Windows 11
- [ ] MSI installs without UAC errors on Windows 10 (with WebView2 bootstrap)
- [ ] NSIS multilingual installer shows both English and Persian language options
- [ ] Application shortcut created in Start Menu
- [ ] Application uninstalls cleanly via Settings → Apps

## First launch
- [ ] Splash screen appears within 300 ms with animated logo
- [ ] Main window appears within 2 s, splash auto-closes
- [ ] Default language is Persian (RTL layout)
- [ ] All original sections visible: crypto, weather, datetime, converter, calculator, health, psychology, banking, guide, ipscanner

## Preservation
- [ ] All Cloudflare IP scanner functions work
- [ ] All crypto price cards load
- [ ] All weather lookups return data
- [ ] All converter modes work (length, mass, temperature, etc.)
- [ ] Scientific calculator computes correctly
- [ ] BMI / BMR / Body-fat calculators return values
- [ ] All psychology tests are accessible
- [ ] Banking loan / deposit / credit-card calculators return amortization tables and charts
- [ ] All original charts render

## Localization
- [ ] Tray → Language → English: UI switches to LTR English mode within 100 ms
- [ ] Section headings (Cryptocurrency, Weather, Calendar, …) display in English
- [ ] Tray → Language → Persian: UI reloads in Persian mode
- [ ] DevTools console: `codeisaI18n.auditReport().missingCount` decreases over time as user completes translations
- [ ] No untranslated alerts in English mode for actions: open modal, switch tab, run calculator, run IP scanner

## Calendar
- [ ] Triple-date card visible in date-time section (Persian / Gregorian / Hijri)
- [ ] Today's events shown
- [ ] Next-holiday countdown displayed
- [ ] Search box filters event list as user types
- [ ] Closing and re-launching the app loads the holiday cache instantly (offline)

## System tray
- [ ] Tray icon visible after launch
- [ ] Right-click shows menu with: Show Window / Language / Network Monitor / Start with Windows / Check for Updates / About / Quit
- [ ] Tray tooltip displays live download/upload speeds, updates each second
- [ ] Double-click left button restores window
- [ ] "Start with Windows" persists across reboots
- [ ] "Quit" terminates the process (verified via Task Manager)

## Minimize-to-tray
- [ ] Clicking the window X button hides to tray (does not exit)
- [ ] Re-opening from tray restores window position and size

## Notifications
- [ ] `window.__TAURI__.invoke('notify', { title: 'Hi', body: 'Test' })` shows a native Windows toast
- [ ] Notification respects Focus Assist settings

## Network monitor
- [ ] Tray tooltip values increase during a download
- [ ] Values return to ≈ 0 B/s during idle
- [ ] CPU usage from `codeisa.exe` remains < 1% during idle monitoring

## Performance
- [ ] Idle CPU < 1 % (Task Manager, 1-min average)
- [ ] Idle RAM < 150 MB
- [ ] Cold start < 2 s on SSD
- [ ] Language switch (FA → EN) < 200 ms

## Auto-update
- [ ] Tray → Check for Updates contacts the configured endpoint (404 acceptable for the placeholder URL — should be silent failure)
- [ ] Once configured with a real endpoint, updater shows a dialog and applies the patch

## Edge cases
- [ ] Launching a second instance brings the first window to focus (single-instance lock)
- [ ] Killing the process via Task Manager does not corrupt window-state cache
- [ ] Resizing the window very small (down to 960×620 min) does not break layout
- [ ] Pressing F11 toggles fullscreen
- [ ] DevTools (F12) opens in dev builds, is disabled in release
