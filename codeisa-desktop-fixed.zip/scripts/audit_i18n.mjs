// Post-mortem i18n audit: re-scans src/index.html, src/*.js and verifies that
// every Persian fragment is either an i18n key value in fa.json or already has
// an English counterpart in en.json. Produces docs/translation-coverage.json.
import { readFileSync, writeFileSync, readdirSync, statSync } from "node:fs";
import { resolve, dirname, extname } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = resolve(__dirname, "..");

const fa = JSON.parse(readFileSync(resolve(root, "locales/fa.json"), "utf8"));
const en = JSON.parse(readFileSync(resolve(root, "locales/en.json"), "utf8"));

function walk(dir, acc = []) {
  for (const e of readdirSync(dir)) {
    const p = resolve(dir, e);
    const st = statSync(p);
    if (st.isDirectory()) walk(p, acc);
    else acc.push(p);
  }
  return acc;
}

const targets = walk(resolve(root, "src")).filter((p) =>
  [".html", ".js", ".css"].includes(extname(p))
);

const PERSIAN = /[\u0600-\u06FF]/;
const knownPersian = new Set(Object.values(fa).map((s) => s.trim()));
const stillUntranslated = [];
for (const [k, v] of Object.entries(en)) {
  if (PERSIAN.test(v)) stillUntranslated.push({ key: k, fa: fa[k], en: v });
}

const report = {
  totalKeys: Object.keys(fa).length,
  translated: Object.keys(fa).length - stillUntranslated.length,
  pending: stillUntranslated.length,
  coveragePercent:
    Math.round(((Object.keys(fa).length - stillUntranslated.length) /
      Math.max(1, Object.keys(fa).length)) *
      10000) / 100,
  pendingKeys: stillUntranslated.slice(0, 500),
};

writeFileSync(
  resolve(root, "docs/translation-coverage.json"),
  JSON.stringify(report, null, 2)
);
console.log(
  `[audit] coverage ${report.coveragePercent}%  translated=${report.translated}  pending=${report.pending}`
);
