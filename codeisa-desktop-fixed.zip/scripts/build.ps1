# =============================================================================
# Codeisa Desktop — One-shot Windows production build script
# -----------------------------------------------------------------------------
# Produces:
#   * Portable EXE       -> src-tauri/target/release/codeisa.exe
#   * NSIS Setup EXE     -> src-tauri/target/release/bundle/nsis/*-setup.exe
#   * MSI installer      -> src-tauri/target/release/bundle/msi/*.msi
#
# Usage  (PowerShell, in repo root):
#   powershell -ExecutionPolicy Bypass -File scripts\build.ps1
#
# Optional switches:
#   -NoMsi      Skip MSI bundling   (only EXE + NSIS setup)
#   -NoNsis     Skip NSIS bundling  (only EXE + MSI)
#   -PortableOnly Just build the .exe with no installers
# =============================================================================

param(
    [switch]$NoMsi,
    [switch]$NoNsis,
    [switch]$PortableOnly
)

$ErrorActionPreference = "Stop"

function Section($msg) {
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host " $msg" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
}

# --- Sanity checks ----------------------------------------------------------
Section "Environment check"

function Need($cmd, $hint) {
    if (-not (Get-Command $cmd -ErrorAction SilentlyContinue)) {
        Write-Host "ERROR: '$cmd' not found." -ForegroundColor Red
        Write-Host $hint -ForegroundColor Yellow
        exit 1
    }
}

Need "node"   "Install Node.js 18+ from https://nodejs.org"
Need "npm"    "npm ships with Node.js"
Need "rustc"  "Install Rust from https://rustup.rs (then: rustup default stable-msvc)"
Need "cargo"  "Install Rust from https://rustup.rs"

$rustVer = (rustc --version)
$nodeVer = (node --version)
Write-Host "  node : $nodeVer"
Write-Host "  rust : $rustVer"

# Make sure the MSVC toolchain is the default on Windows
$activeToolchain = (rustup show active-toolchain 2>$null)
if ($activeToolchain -notmatch "msvc") {
    Write-Host "WARNING: active rust toolchain is not -msvc ($activeToolchain)" -ForegroundColor Yellow
    Write-Host "Switching to stable-x86_64-pc-windows-msvc..." -ForegroundColor Yellow
    rustup default stable-x86_64-pc-windows-msvc
    rustup target add x86_64-pc-windows-msvc
}

# --- Determine bundle targets ----------------------------------------------
$bundles = @()
if ($PortableOnly) {
    $bundleArg = @()  # do not pass --bundles, but we'll use a custom call
} else {
    if (-not $NoNsis) { $bundles += "nsis" }
    if (-not $NoMsi)  { $bundles += "msi" }
}

# --- Frontend deps ---------------------------------------------------------
Section "Installing frontend dependencies"
npm install --no-audit --no-fund

# --- Build -----------------------------------------------------------------
Section "Building (release) — this can take 5-15 minutes the first time"

if ($PortableOnly) {
    # Build only the binary, no bundler
    Push-Location src-tauri
    cargo build --release --target x86_64-pc-windows-msvc
    Pop-Location
} else {
    $bundleCsv = ($bundles -join ",")
    Write-Host "Bundles: $bundleCsv"
    npx tauri build --bundles $bundleCsv
}

# --- Collect artifacts -----------------------------------------------------
Section "Collecting artifacts"

$outDir = Join-Path $PSScriptRoot "..\dist"
New-Item -ItemType Directory -Force -Path $outDir | Out-Null

$exe = Get-ChildItem -Recurse -Path "src-tauri\target\release" -Filter "codeisa.exe" -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -notmatch "\\deps\\|\\build\\" } | Select-Object -First 1
if ($exe) {
    Copy-Item $exe.FullName (Join-Path $outDir "Codeisa-Portable.exe") -Force
    Write-Host "  Portable EXE  -> dist\Codeisa-Portable.exe" -ForegroundColor Green
}

Get-ChildItem -Recurse -Path "src-tauri\target\release\bundle" -Include *.exe, *.msi -ErrorAction SilentlyContinue | ForEach-Object {
    Copy-Item $_.FullName $outDir -Force
    Write-Host "  Installer     -> dist\$($_.Name)" -ForegroundColor Green
}

Section "Done"
Write-Host "All artifacts are in:  $((Resolve-Path $outDir).Path)" -ForegroundColor Green
