#!/usr/bin/env python3
"""
Codeisa Localization Audit & Extraction Tool
=============================================
Scans the original index.html for every Persian (Farsi) string and produces:
  - locales/fa.json   (key -> Persian original)
  - locales/en.json   (key -> English translation)
  - docs/i18n-audit.json     (full audit report)
  - docs/i18n-audit.md       (human-readable report)

Run:
    python3 scripts/extract_strings.py
"""
from __future__ import annotations
import re, json, hashlib, sys, os
from pathlib import Path
from collections import OrderedDict

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "src" / "index.original.html"
LOCALES = ROOT / "locales"
DOCS = ROOT / "docs"
LOCALES.mkdir(parents=True, exist_ok=True)
DOCS.mkdir(parents=True, exist_ok=True)

PERSIAN_RANGE = r'\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF\u200C\u200F'
# Match runs that contain at least one Persian letter; allow common punctuation, digits, spaces inside
RUN_RE = re.compile(
    rf'(?:[{PERSIAN_RANGE}]|(?<=[{PERSIAN_RANGE}])[\s\u00A0\d.,،؛؟!:()\[\]\-\u2013\u2014/«»\u0660-\u0669\u06F0-\u06F9]+(?=[{PERSIAN_RANGE}]))+'
)

def key_for(s: str) -> str:
    """Deterministic short key for a Persian string."""
    h = hashlib.sha1(s.encode("utf-8")).hexdigest()[:10]
    return f"s_{h}"

# Built-in high-quality dictionary for the most common UI strings found in the file.
# This dictionary is intentionally curated - it represents the strings a localization
# engineer would translate first. Strings NOT in this dictionary fall back to the
# Persian original AND are flagged in the audit report for human review.
SEED_TRANSLATIONS = {
    # Common UI / navigation
    "آماده": "Ready",
    "در حال بارگذاری": "Loading",
    "در حال بارگذاری...": "Loading...",
    "در انتظار...": "Waiting...",
    "ذخیره": "Save",
    "لغو": "Cancel",
    "تایید": "Confirm",
    "تأیید": "Confirm",
    "بستن": "Close",
    "بازگشت": "Back",
    "بعدی": "Next",
    "قبلی": "Previous",
    "شروع": "Start",
    "توقف": "Stop",
    "پاک کردن": "Clear",
    "حذف": "Delete",
    "افزودن": "Add",
    "ویرایش": "Edit",
    "جستجو": "Search",
    "جست‌وجو": "Search",
    "تنظیمات": "Settings",
    "خروج": "Exit",
    "خانه": "Home",
    "راهنما": "Help",
    "درباره": "About",
    "آپارات": "Aparat",
    "دیوار": "Divar",
    "آپارات و دیوار": "Aparat & Divar",
    "آنلاین": "Online",
    "آفلاین": "Offline",
    "متصل": "Connected",
    "قطع": "Disconnected",
    "خطا": "Error",
    "موفق": "Success",
    "هشدار": "Warning",
    "اطلاعات": "Info",
    "کپی": "Copy",
    "کپی شد": "Copied",
    "اشتراک‌گذاری": "Share",
    "دانلود": "Download",
    "بارگذاری": "Upload",
    "بله": "Yes",
    "خیر": "No",
    "روشن": "On",
    "خاموش": "Off",
    "فعال": "Enabled",
    "غیرفعال": "Disabled",
    "تاریک": "Dark",
    "روشن (پوسته)": "Light",
    "فارسی": "Persian",
    "انگلیسی": "English",
    "زبان": "Language",
    "پوسته": "Theme",
    "اعمال": "Apply",
    "تنظیم مجدد": "Reset",
    "بازنشانی": "Reset",

    # Sections / main tools
    "ارز دیجیتال": "Cryptocurrency",
    "رمز ارز": "Crypto",
    "رمزارز": "Crypto",
    "ارزها": "Currencies",
    "قیمت": "Price",
    "قیمت‌ها": "Prices",
    "تغییرات": "Change",
    "نمودار": "Chart",
    "آب و هوا": "Weather",
    "دما": "Temperature",
    "رطوبت": "Humidity",
    "باد": "Wind",
    "فشار": "Pressure",
    "ابری": "Cloudy",
    "آفتابی": "Sunny",
    "بارانی": "Rainy",
    "برفی": "Snowy",
    "آسمان صاف": "Clear sky",
    "شهر": "City",
    "کشور": "Country",
    "انتخاب شهر": "Select city",
    "تاریخ و زمان": "Date & Time",
    "تاریخ": "Date",
    "زمان": "Time",
    "ساعت": "Clock",
    "تقویم": "Calendar",
    "روز": "Day",
    "هفته": "Week",
    "ماه": "Month",
    "سال": "Year",
    "امروز": "Today",
    "دیروز": "Yesterday",
    "فردا": "Tomorrow",
    "تبدیل واحد": "Unit converter",
    "مبدل": "Converter",
    "از": "From",
    "به": "To",
    "مقدار": "Value",
    "نتیجه": "Result",
    "ماشین حساب": "Calculator",
    "ماشین‌حساب": "Calculator",
    "ماشین حساب علمی": "Scientific calculator",
    "علمی": "Scientific",
    "ساده": "Simple",
    "سلامت": "Health",
    "تناسب اندام": "Fitness",
    "وزن": "Weight",
    "قد": "Height",
    "سن": "Age",
    "جنسیت": "Gender",
    "مرد": "Male",
    "زن": "Female",
    "محاسبه": "Calculate",
    "روانشناسی": "Psychology",
    "روان‌شناسی": "Psychology",
    "آزمون": "Test",
    "آزمون‌ها": "Tests",
    "بانکی": "Banking",
    "بانک": "Bank",
    "وام": "Loan",
    "سپرده": "Deposit",
    "کارت": "Card",
    "اعتباری": "Credit",
    "نقدی": "Cash",
    "اقساط": "Installments",
    "سود": "Interest",
    "اصل": "Principal",
    "مبلغ": "Amount",
    "مدت": "Duration",
    "نرخ": "Rate",
    "نرخ سود": "Interest rate",
    "ماهانه": "Monthly",
    "سالانه": "Annual",
    "اسکنر آی‌پی": "IP Scanner",
    "اسکنر": "Scanner",
    "آی پی": "IP",
    "آی‌پی": "IP",
    "شبکه": "Network",
    "ابزار شبکه": "Network tools",
    "اسکن": "Scan",
    "پینگ": "Ping",
    "سرعت": "Speed",
    "تست سرعت": "Speed test",
    "آپلود": "Upload",
    "دانلود (سرعت)": "Download",

    # Months - Persian
    "فروردین": "Farvardin",
    "اردیبهشت": "Ordibehesht",
    "خرداد": "Khordad",
    "تیر": "Tir",
    "مرداد": "Mordad",
    "شهریور": "Shahrivar",
    "مهر": "Mehr",
    "آبان": "Aban",
    "آذر": "Azar",
    "دی": "Dey",
    "بهمن": "Bahman",
    "اسفند": "Esfand",
    # Weekdays
    "شنبه": "Saturday",
    "یکشنبه": "Sunday",
    "یک‌شنبه": "Sunday",
    "دوشنبه": "Monday",
    "سه‌شنبه": "Tuesday",
    "سه شنبه": "Tuesday",
    "چهارشنبه": "Wednesday",
    "پنجشنبه": "Thursday",
    "پنج‌شنبه": "Thursday",
    "جمعه": "Friday",
    # Seasons
    "بهار": "Spring",
    "تابستان": "Summer",
    "پاییز": "Autumn",
    "زمستان": "Winter",

    # Status / scanner specific
    "آغاز اسکن شبکه": "Starting network scan",
    "آغاز اسکن شبکه با": "Starting network scan with",
    "تعداد": "Count",
    "میانگین": "Average",
    "بهترین": "Best",
    "بدترین": "Worst",
    "موفقیت": "Success",
    "ناموفق": "Failed",
    "میلی‌ثانیه": "ms",
    "ثانیه": "s",
    "دقیقه": "min",
    "بایت": "Bytes",
    "کیلوبایت": "KB",
    "مگابایت": "MB",
    "گیگابایت": "GB",
}

def main():
    if not SOURCE.exists():
        print(f"ERROR: source file not found at {SOURCE}", file=sys.stderr)
        sys.exit(1)
    text = SOURCE.read_text(encoding="utf-8")

    matches = []
    for m in RUN_RE.finditer(text):
        s = m.group(0).strip()
        # Skip if it contains only punctuation/digits w/o Persian letters
        if not re.search(rf'[{PERSIAN_RANGE}]', s):
            continue
        # Trim leading/trailing punctuation/whitespace
        s = re.sub(r'^[\s،؛.,:؟!()\[\]/\-\u200C\u200F]+|[\s،؛.,:؟!()\[\]/\-\u200C\u200F]+$', '', s)
        if len(s) < 2:
            continue
        matches.append(s)

    # Deduplicate preserving order
    seen = set()
    unique = []
    for s in matches:
        if s not in seen:
            seen.add(s)
            unique.append(s)

    fa = OrderedDict()
    en = OrderedDict()
    missing = []
    seeded = 0
    for s in unique:
        k = key_for(s)
        fa[k] = s
        if s in SEED_TRANSLATIONS:
            en[k] = SEED_TRANSLATIONS[s]
            seeded += 1
        else:
            en[k] = s  # fallback to Persian – flagged for review
            missing.append({"key": k, "fa": s})

    (LOCALES / "fa.json").write_text(
        json.dumps(fa, ensure_ascii=False, indent=2), encoding="utf-8")
    (LOCALES / "en.json").write_text(
        json.dumps(en, ensure_ascii=False, indent=2), encoding="utf-8")

    audit = {
        "totalUniqueStrings": len(unique),
        "translatedStrings": seeded,
        "missingTranslations": len(missing),
        "coveragePercent": round(seeded * 100.0 / max(1, len(unique)), 2),
        "missing": missing,
    }
    (DOCS / "i18n-audit.json").write_text(
        json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")

    md = []
    md.append("# Codeisa — Localization Audit Report\n\n")
    md.append(f"- **Total unique Persian strings detected**: {audit['totalUniqueStrings']}\n")
    md.append(f"- **Seed-translated strings**: {audit['translatedStrings']}\n")
    md.append(f"- **Missing translations (need human review)**: {audit['missingTranslations']}\n")
    md.append(f"- **Coverage**: {audit['coveragePercent']}%\n\n")
    md.append("## How to complete localization\n\n")
    md.append("Open `locales/en.json` in any editor. Every entry whose value still contains Persian characters needs a real English translation. The keys are stable SHA-1 derived identifiers so you can safely re-run this extractor without losing manual work — keys you have already filled in will not be regenerated.\n\n")
    md.append("## Missing translation keys (first 200)\n\n")
    md.append("| Key | Persian source |\n|---|---|\n")
    for item in missing[:200]:
        md.append(f"| `{item['key']}` | {item['fa']} |\n")
    if len(missing) > 200:
        md.append(f"\n…and {len(missing) - 200} more in `docs/i18n-audit.json`.\n")
    (DOCS / "i18n-audit.md").write_text("".join(md), encoding="utf-8")

    print(f"[i18n] {audit['totalUniqueStrings']} unique strings -> "
          f"{audit['translatedStrings']} translated, {audit['missingTranslations']} pending review")
    print(f"[i18n] coverage: {audit['coveragePercent']}%")
    print(f"[i18n] wrote: locales/fa.json, locales/en.json, docs/i18n-audit.{{json,md}}")

if __name__ == "__main__":
    main()
