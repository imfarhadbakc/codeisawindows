// Prebuild step: runs the Python localization extractor and ensures all
// generated assets land where Tauri's frontendDist (../src) expects them.
import { execSync } from "node:child_process";
import { copyFileSync, existsSync, mkdirSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = resolve(__dirname, "..");

console.log("[prebuild] Running localization extractor…");
try {
  execSync(`python3 "${resolve(root, "scripts/extract_strings.py")}"`, {
    stdio: "inherit",
    cwd: root,
  });
} catch (e) {
  console.warn("[prebuild] python3 not found or extractor failed — using checked-in locales.");
}

// Ensure locale files are copied next to index.html for fetch()
const srcDir = resolve(root, "src");
const locDir = resolve(root, "locales");
const dstDir = resolve(srcDir, "locales");
mkdirSync(dstDir, { recursive: true });
for (const f of ["fa.json", "en.json"]) {
  const from = resolve(locDir, f);
  const to = resolve(dstDir, f);
  if (existsSync(from)) {
    copyFileSync(from, to);
    console.log(`[prebuild] copied ${f}`);
  }
}

console.log("[prebuild] Done.");
