// ============================================================================
// Codeisa Desktop — Tauri backend
// ----------------------------------------------------------------------------
// Responsibilities:
//   - Splash screen lifecycle
//   - System tray with bilingual menu
//   - Minimize to tray
//   - Native notifications
//   - Native network monitor (download / upload bytes per second)
//   - Auto-start with Windows
//   - Single-instance enforcement
// ============================================================================

use std::sync::Arc;
use std::time::{Duration, Instant};

use parking_lot::Mutex;
use serde::Serialize;
use tauri::{
    image::Image,
    menu::{Menu, MenuEvent, MenuItem, PredefinedMenuItem, Submenu},
    tray::{MouseButton, TrayIconBuilder, TrayIconEvent},
    AppHandle, Emitter, Manager, RunEvent, WindowEvent,
};

mod network;

#[derive(Default)]
pub struct AppState {
    pub lang: Mutex<String>,
}

#[derive(Clone, Serialize)]
pub struct NetStats {
    pub down_bps: u64,
    pub up_bps: u64,
    pub total_down: u64,
    pub total_up: u64,
}

#[tauri::command]
async fn show_main_window(app: AppHandle) -> Result<(), String> {
    if let Some(main) = app.get_webview_window("main") {
        let _ = main.show();
        let _ = main.set_focus();
        let _ = main.unminimize();
    }
    if let Some(splash) = app.get_webview_window("splash") {
        let _ = splash.close();
    }
    Ok(())
}

#[tauri::command]
async fn register_global_state(app: AppHandle, lang: String) -> Result<(), String> {
    let state = app.state::<AppState>();
    *state.lang.lock() = lang;
    Ok(())
}

#[tauri::command]
async fn get_network_stats(app: AppHandle) -> Result<NetStats, String> {
    let monitor = app.state::<Arc<network::NetworkMonitor>>();
    Ok(monitor.snapshot())
}

#[tauri::command]
async fn quit_app(app: AppHandle) -> Result<(), String> {
    app.exit(0);
    Ok(())
}

#[tauri::command]
async fn set_autostart(app: AppHandle, enabled: bool) -> Result<(), String> {
    use tauri_plugin_autostart::ManagerExt;
    let manager = app.autolaunch();
    if enabled {
        manager.enable().map_err(|e| e.to_string())?;
    } else {
        manager.disable().map_err(|e| e.to_string())?;
    }
    Ok(())
}

#[tauri::command]
async fn notify(
    app: AppHandle,
    title: String,
    body: String,
) -> Result<(), String> {
    use tauri_plugin_notification::NotificationExt;
    app.notification()
        .builder()
        .title(title)
        .body(body)
        .show()
        .map_err(|e| e.to_string())?;
    Ok(())
}

fn build_tray(app: &AppHandle) -> tauri::Result<()> {
    let lang = app.state::<AppState>().lang.lock().clone();
    let is_fa = lang == "fa";

    let lbl_open      = if is_fa { "نمایش پنجره" }       else { "Show Window" };
    let lbl_lang      = if is_fa { "زبان" }              else { "Language" };
    let lbl_fa        = if is_fa { "فارسی" }             else { "Persian" };
    let lbl_en        = if is_fa { "انگلیسی" }           else { "English" };
    let lbl_autostart = if is_fa { "اجرا با ویندوز" }     else { "Start with Windows" };
    let lbl_check_upd = if is_fa { "بررسی به‌روزرسانی" }   else { "Check for Updates" };
    let lbl_net       = if is_fa { "مانیتور شبکه" }       else { "Network Monitor" };
    let lbl_about     = if is_fa { "درباره" }            else { "About" };
    let lbl_quit      = if is_fa { "خروج" }              else { "Quit" };

    let open    = MenuItem::with_id(app, "open",        lbl_open, true, None::<&str>)?;
    let fa      = MenuItem::with_id(app, "lang_fa",     lbl_fa,   true, None::<&str>)?;
    let en      = MenuItem::with_id(app, "lang_en",     lbl_en,   true, None::<&str>)?;
    let auto    = MenuItem::with_id(app, "autostart",   lbl_autostart, true, None::<&str>)?;
    let upd     = MenuItem::with_id(app, "check_upd",   lbl_check_upd, true, None::<&str>)?;
    let net     = MenuItem::with_id(app, "net",         lbl_net, true, None::<&str>)?;
    let about   = MenuItem::with_id(app, "about",       lbl_about, true, None::<&str>)?;
    let quit    = MenuItem::with_id(app, "quit",        lbl_quit, true, None::<&str>)?;
    let sep     = PredefinedMenuItem::separator(app)?;

    let lang_menu = Submenu::with_id_and_items(app, "lang", lbl_lang, true, &[&fa, &en])?;

    let menu = Menu::with_items(
        app,
        &[&open, &sep, &lang_menu, &auto, &net, &sep, &upd, &about, &sep, &quit],
    )?;

    let icon_bytes: &[u8] = include_bytes!("../icons/icon.png");
    let icon = Image::from_bytes(icon_bytes).unwrap_or_else(|_| {
        Image::new_owned(vec![0u8; 4], 1, 1)
    });

    let _tray = TrayIconBuilder::with_id("codeisa-tray")
        .icon(icon)
        .tooltip("Codeisa")
        .menu(&menu)
        .show_menu_on_left_click(false)
        .on_menu_event(handle_menu_event)
        .on_tray_icon_event(|tray, event| {
            if let TrayIconEvent::DoubleClick { button: MouseButton::Left, .. } = event {
                if let Some(win) = tray.app_handle().get_webview_window("main") {
                    let _ = win.show();
                    let _ = win.set_focus();
                    let _ = win.unminimize();
                }
            }
        })
        .build(app)?;

    Ok(())
}

fn handle_menu_event(app: &AppHandle, event: MenuEvent) {
    match event.id.as_ref() {
        "open" => {
            if let Some(w) = app.get_webview_window("main") {
                let _ = w.show();
                let _ = w.set_focus();
                let _ = w.unminimize();
            }
        }
        "lang_fa" => {
            *app.state::<AppState>().lang.lock() = "fa".into();
            let _ = app.emit("codeisa://set-language", "fa");
            let _ = build_tray(app); // rebuild with new labels
        }
        "lang_en" => {
            *app.state::<AppState>().lang.lock() = "en".into();
            let _ = app.emit("codeisa://set-language", "en");
            let _ = build_tray(app);
        }
        "autostart" => {
            use tauri_plugin_autostart::ManagerExt;
            let mgr = app.autolaunch();
            let is_on = mgr.is_enabled().unwrap_or(false);
            let _ = if is_on { mgr.disable() } else { mgr.enable() };
        }
        "check_upd" => {
            #[cfg(desktop)]
            {
                use tauri_plugin_updater::UpdaterExt;
                let app_handle = app.clone();
                tauri::async_runtime::spawn(async move {
                    match app_handle.updater() {
                        Ok(updater) => {
                            if let Ok(Some(update)) = updater.check().await {
                                let _ = update
                                    .download_and_install(|_, _| {}, || {})
                                    .await;
                            }
                        }
                        Err(_) => {}
                    }
                });
            }
        }
        "net" => {
            if let Some(w) = app.get_webview_window("main") {
                let _ = w.show();
                let _ = w.set_focus();
            }
            let _ = app.emit("codeisa://show-network-monitor", true);
        }
        "about" => {
            let _ = app.emit("codeisa://show-about", true);
            if let Some(w) = app.get_webview_window("main") {
                let _ = w.show();
                let _ = w.set_focus();
            }
        }
        "quit" => {
            app.exit(0);
        }
        _ => {}
    }
}

pub fn run() {
    let app_state = AppState::default();
    *app_state.lang.lock() = "fa".to_string();

    tauri::Builder::default()
        .plugin(tauri_plugin_single_instance::init(|app, _, _| {
            if let Some(w) = app.get_webview_window("main") {
                let _ = w.show();
                let _ = w.set_focus();
                let _ = w.unminimize();
            }
        }))
        .plugin(tauri_plugin_window_state::Builder::default().build())
        .plugin(tauri_plugin_notification::init())
        .plugin(tauri_plugin_autostart::init(
            tauri_plugin_autostart::MacosLauncher::LaunchAgent,
            Some(vec![]),
        ))
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_fs::init())
        .plugin(tauri_plugin_http::init())
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_os::init())
        .plugin(tauri_plugin_process::init())
        .plugin(tauri_plugin_updater::Builder::new().build())
        .manage(app_state)
        .invoke_handler(tauri::generate_handler![
            show_main_window,
            register_global_state,
            get_network_stats,
            set_autostart,
            notify,
            quit_app,
        ])
        .setup(|app| {
            // Start the network monitor
            let monitor = Arc::new(network::NetworkMonitor::new());
            app.manage(monitor.clone());
            let app_handle = app.handle().clone();
            std::thread::spawn(move || {
                let mut last_emit = Instant::now();
                loop {
                    monitor.tick();
                    if last_emit.elapsed() >= Duration::from_secs(1) {
                        let snap = monitor.snapshot();
                        let _ = app_handle.emit("codeisa://network-stats", &snap);
                        // Tooltip update
                        if let Some(tray) = app_handle.tray_by_id("codeisa-tray") {
                            let dn = pretty_bps(snap.down_bps);
                            let up = pretty_bps(snap.up_bps);
                            let _ = tray.set_tooltip(Some(format!("Codeisa  ⬇ {dn}  ⬆ {up}")));
                        }
                        last_emit = Instant::now();
                    }
                    std::thread::sleep(Duration::from_millis(500));
                }
            });

            // Build tray
            build_tray(app.handle())?;

            // Splash auto-close fallback (in case the frontend forgets to emit ready)
            let app_handle = app.handle().clone();
            tauri::async_runtime::spawn(async move {
                tokio::time::sleep(Duration::from_secs(5)).await;
                if let Some(main) = app_handle.get_webview_window("main") {
                    if !main.is_visible().unwrap_or(false) {
                        let _ = main.show();
                        let _ = main.set_focus();
                    }
                }
                if let Some(splash) = app_handle.get_webview_window("splash") {
                    let _ = splash.close();
                }
            });

            Ok(())
        })
        .on_window_event(|window, event| {
            if let WindowEvent::CloseRequested { api, .. } = event {
                if window.label() == "main" {
                    // Minimize to tray instead of closing
                    let _ = window.hide();
                    api.prevent_close();
                }
            }
        })
        .build(tauri::generate_context!())
        .expect("error while building Codeisa application")
        .run(|_app_handle, event| {
            if let RunEvent::ExitRequested { .. } = event {
                // allow exit
            }
        });
}

fn pretty_bps(b: u64) -> String {
    const K: f64 = 1024.0;
    let b = b as f64;
    if b < K { format!("{:.0} B/s", b) }
    else if b < K * K { format!("{:.1} KB/s", b / K) }
    else if b < K * K * K { format!("{:.1} MB/s", b / (K * K)) }
    else { format!("{:.2} GB/s", b / (K * K * K)) }
}
