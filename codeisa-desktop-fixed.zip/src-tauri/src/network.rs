// ============================================================================
// Codeisa Desktop — Native network monitor
// ----------------------------------------------------------------------------
// Uses sysinfo to read OS-level NIC counters. Computes per-second deltas with
// minimal CPU overhead (one refresh every 500ms, lock-free atomic snapshot).
// ============================================================================

use std::time::Instant;

use parking_lot::Mutex;
use sysinfo::Networks;

use crate::NetStats;

pub struct NetworkMonitor {
    inner: Mutex<Inner>,
}

struct Inner {
    networks: Networks,
    last_tick: Instant,
    down_bps: u64,
    up_bps: u64,
    total_down: u64,
    total_up: u64,
}

impl NetworkMonitor {
    pub fn new() -> Self {
        // `new_with_refreshed_list` loads the interface list AND fills initial counters,
        // so the first delta is computed against a real baseline (not zero).
        let networks = Networks::new_with_refreshed_list();
        Self {
            inner: Mutex::new(Inner {
                networks,
                last_tick: Instant::now(),
                down_bps: 0,
                up_bps: 0,
                total_down: 0,
                total_up: 0,
            }),
        }
    }

    pub fn tick(&self) {
        let mut g = self.inner.lock();

        // sysinfo 0.31 API: `refresh()` takes no arguments. After it runs,
        // `received()` / `transmitted()` return the deltas since this call.
        g.networks.refresh();

        let now = Instant::now();
        let dt = now.duration_since(g.last_tick).as_secs_f64().max(0.001);

        let mut delta_down: u64 = 0;
        let mut delta_up: u64 = 0;
        let mut total_down: u64 = 0;
        let mut total_up: u64 = 0;

        for (_iface, data) in g.networks.iter() {
            delta_down = delta_down.saturating_add(data.received());
            delta_up = delta_up.saturating_add(data.transmitted());
            total_down = total_down.saturating_add(data.total_received());
            total_up = total_up.saturating_add(data.total_transmitted());
        }

        g.down_bps = ((delta_down as f64) / dt) as u64;
        g.up_bps = ((delta_up as f64) / dt) as u64;
        g.total_down = total_down;
        g.total_up = total_up;
        g.last_tick = now;
    }

    pub fn snapshot(&self) -> NetStats {
        let g = self.inner.lock();
        NetStats {
            down_bps: g.down_bps,
            up_bps: g.up_bps,
            total_down: g.total_down,
            total_up: g.total_up,
        }
    }
}
