/* ============================================================================
 * Codeisa — Advanced Calendar Pro
 * ----------------------------------------------------------------------------
 * Triple calendar (Jalali/Gregorian/Hijri) + Iranian holidays/occasions DB.
 * Coverage: previous 2 years, current year, next 5 years.
 *
 * Public API (window.codeisaCalendarPro):
 *   - todayInfo()                       -> { fa, gr, hj, weekday, season, todayEvents }
 *   - eventsForJalali(year, month, day) -> Event[]
 *   - nextHoliday(fromJYear, fromJMonth, fromJDay) -> { event, daysUntil }
 *   - search(query)                     -> Event[]
 *   - filter(category)                  -> Event[]
 *   - mount(rootElementId)              -> Render the full calendar UI into the given root
 * ============================================================================ */
(function () {
  "use strict";

  // ---------- Jalali <-> Gregorian conversion (Borkowski algorithm) ----------
  function div(a, b) { return Math.trunc(a / b); }
  function jalaliToGregorian(jy, jm, jd) {
    jy = +jy; jm = +jm; jd = +jd;
    let sal_a = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365];
    let gy = jy <= 979 ? 621 : 1600;
    jy -= jy <= 979 ? 0 : 979;
    let days = (365 * jy) + (div(jy, 33) * 8) + div(((jy % 33) + 3), 4) +
      78 + jd + (jm < 7 ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
    gy += 400 * div(days, 146097); days %= 146097;
    if (days > 36524) { gy += 100 * div(--days, 36524); days %= 36524; if (days >= 365) days++; }
    gy += 4 * div(days, 1461); days %= 1461;
    if (days > 365) { gy += div(days - 1, 365); days = (days - 1) % 365; }
    let gd = days + 1, gm;
    let sal_b = [0, 31, ((gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0) ? 29 : 28,
      31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    for (gm = 0; gm < 13 && gd > sal_b[gm]; gm++) gd -= sal_b[gm];
    return [gy, gm, gd];
  }
  function gregorianToJalali(gy, gm, gd) {
    gy = +gy; gm = +gm; gd = +gd;
    let g_d_m = [0, 31, ((gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0) ? 29 : 28,
      31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    let gy2 = (gm > 2) ? (gy + 1) : gy;
    let days = 355666 + (365 * gy) + div((gy2 + 3), 4) - div((gy2 + 99), 100) + div((gy2 + 399), 400) + gd;
    for (let i = 0; i < gm; i++) days += g_d_m[i];
    let jy = -1595 + (33 * div(days, 12053)); days %= 12053;
    jy += 4 * div(days, 1461); days %= 1461;
    if (days > 365) { jy += div(days - 1, 365); days = (days - 1) % 365; }
    let jm = (days < 186) ? 1 + div(days, 31) : 7 + div(days - 186, 30);
    let jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
    return [jy, jm, jd];
  }
  // Simple Hijri (Umm al-Qura approximation via Kuwaiti algorithm)
  function gregorianToHijri(gy, gm, gd) {
    const jd = gregorianToJulianDay(gy, gm, gd);
    const l = jd - 1948440 + 10632;
    const n = Math.trunc((l - 1) / 10631);
    const l1 = l - 10631 * n + 354;
    const j = Math.trunc((10985 - l1) / 5316) * Math.trunc(50 * l1 / 17719) +
      Math.trunc(l1 / 5670) * Math.trunc(43 * l1 / 15238);
    const l2 = l1 - Math.trunc((30 - j) / 15) * Math.trunc((17719 * j) / 50) -
      Math.trunc(j / 16) * Math.trunc((15238 * j) / 43) + 29;
    const hm = Math.trunc((24 * l2) / 709);
    const hd = l2 - Math.trunc((709 * hm) / 24);
    const hy = 30 * n + j - 30;
    return [hy, hm, hd];
  }
  function gregorianToJulianDay(gy, gm, gd) {
    if (gm < 3) { gy -= 1; gm += 12; }
    const a = Math.trunc(gy / 100);
    const b = 2 - a + Math.trunc(a / 4);
    return Math.trunc(365.25 * (gy + 4716)) + Math.trunc(30.6001 * (gm + 1)) + gd + b - 1524;
  }

  // ---------- Iranian holidays / occasions database ----------
  // Categories: official | religious | national | cultural | international
  // Each entry has a Jalali month/day, optional Hijri month/day (for religious lunar dates),
  // optional Gregorian month/day (for international occasions), and bilingual labels.
  // For lunar (Hijri-based) events, the resolver re-projects them onto Jalali for each year.
  const STATIC_JALALI_EVENTS = [
    // --- Official holidays (Persian calendar based) ---
    { jm: 1, jd: 1, cat: "official", holiday: true, fa: "نوروز / جشن سال نو", en: "Nowruz / Persian New Year" },
    { jm: 1, jd: 2, cat: "official", holiday: true, fa: "عید نوروز", en: "Nowruz" },
    { jm: 1, jd: 3, cat: "official", holiday: true, fa: "عید نوروز", en: "Nowruz" },
    { jm: 1, jd: 4, cat: "official", holiday: true, fa: "عید نوروز", en: "Nowruz" },
    { jm: 1, jd: 12, cat: "official", holiday: true, fa: "روز جمهوری اسلامی ایران", en: "Islamic Republic Day" },
    { jm: 1, jd: 13, cat: "official", holiday: true, fa: "روز طبیعت (سیزده‌بدر)", en: "Nature Day (Sizdah-bedar)" },
    { jm: 3, jd: 14, cat: "official", holiday: true, fa: "رحلت امام خمینی (ره)", en: "Demise of Imam Khomeini" },
    { jm: 3, jd: 15, cat: "official", holiday: true, fa: "قیام ۱۵ خرداد", en: "Uprising of Khordad 15" },
    { jm: 11, jd: 22, cat: "official", holiday: true, fa: "پیروزی انقلاب اسلامی", en: "Victory of the Islamic Revolution" },
    { jm: 12, jd: 29, cat: "official", holiday: true, fa: "روز ملی شدن صنعت نفت", en: "Nationalization of the Oil Industry" },

    // --- National / cultural occasions (non-holiday by default) ---
    { jm: 1, jd: 6, cat: "cultural", fa: "روز امید، روز بزرگداشت زرتشت", en: "Day of Hope, Zoroaster Commemoration" },
    { jm: 2, jd: 1, cat: "cultural", fa: "روز بزرگداشت سعدی", en: "Saadi Commemoration Day" },
    { jm: 2, jd: 3, cat: "cultural", fa: "روز بزرگداشت شیخ بهایی / روز معلم (۱۲ اردیبهشت)", en: "Sheikh Bahai Commemoration Day" },
    { jm: 2, jd: 10, cat: "cultural", fa: "روز ملی خلیج فارس", en: "National Persian Gulf Day" },
    { jm: 2, jd: 12, cat: "national", fa: "روز معلم", en: "Teacher's Day" },
    { jm: 2, jd: 25, cat: "cultural", fa: "روز بزرگداشت فردوسی", en: "Ferdowsi Commemoration Day" },
    { jm: 3, jd: 1, cat: "cultural", fa: "روز بزرگداشت ملاصدرا", en: "Mulla Sadra Commemoration Day" },
    { jm: 3, jd: 4, cat: "national", fa: "روز دزفول، روز مقاومت و پایداری", en: "Day of Resistance and Endurance" },
    { jm: 4, jd: 1, cat: "cultural", fa: "روز اصناف", en: "Day of Guilds" },
    { jm: 4, jd: 7, cat: "national", fa: "روز قلم", en: "Day of the Pen" },
    { jm: 4, jd: 10, cat: "national", fa: "روز صنعت و معدن", en: "Day of Industry and Mines" },
    { jm: 5, jd: 5, cat: "cultural", fa: "روز بزرگداشت شیخ شهاب‌الدین سهروردی", en: "Suhrawardi Commemoration Day" },
    { jm: 5, jd: 14, cat: "national", fa: "روز اهدای خون", en: "Blood Donation Day" },
    { jm: 6, jd: 1, cat: "cultural", fa: "روز بزرگداشت ابوعلی سینا، روز پزشک", en: "Avicenna Day / Doctor's Day" },
    { jm: 6, jd: 31, cat: "national", fa: "آغاز هفته دفاع مقدس", en: "Start of Sacred Defence Week" },
    { jm: 7, jd: 8, cat: "cultural", fa: "روز بزرگداشت مولوی", en: "Rumi Commemoration Day" },
    { jm: 7, jd: 13, cat: "national", fa: "روز نیروی انتظامی", en: "Police Force Day" },
    { jm: 7, jd: 20, cat: "cultural", fa: "روز بزرگداشت حافظ", en: "Hafez Commemoration Day" },
    { jm: 7, jd: 24, cat: "national", fa: "روز پیوند اولیا و مربیان", en: "Parents-Teachers Bond Day" },
    { jm: 8, jd: 13, cat: "national", fa: "روز دانش‌آموز", en: "Student Day" },
    { jm: 9, jd: 1, cat: "national", fa: "روز نیروی دریایی", en: "Navy Day" },
    { jm: 9, jd: 30, cat: "cultural", fa: "شب یلدا (چله)", en: "Yalda Night (Chelleh)" },
    { jm: 10, jd: 19, cat: "national", fa: "روز جهاد کشاورزی", en: "Agricultural Jihad Day" },
    { jm: 11, jd: 19, cat: "national", fa: "روز نیروی هوایی", en: "Air Force Day" },
    { jm: 12, jd: 5, cat: "cultural", fa: "روز بزرگداشت خواجه نصیرالدین طوسی / روز مهندس", en: "Nasir al-Din al-Tusi Day / Engineer's Day" },
    { jm: 12, jd: 25, cat: "cultural", fa: "چهارشنبه‌سوری (شب آخرین چهارشنبه سال)", en: "Chaharshanbe Suri (last Tuesday eve)" },

    // --- Persian seasonal markers ---
    { jm: 4, jd: 1, cat: "cultural", fa: "آغاز تابستان", en: "Start of Summer" },
    { jm: 7, jd: 1, cat: "cultural", fa: "آغاز پاییز", en: "Start of Autumn" },
    { jm: 10, jd: 1, cat: "cultural", fa: "آغاز زمستان", en: "Start of Winter" },
  ];

  // Hijri-based religious occasions (apply per-year by projection)
  const STATIC_HIJRI_EVENTS = [
    { hm: 1, hd: 1, cat: "religious", holiday: false, fa: "آغاز سال هجری قمری", en: "Hijri New Year" },
    { hm: 1, hd: 9, cat: "religious", holiday: true, fa: "تاسوعای حسینی", en: "Tasua of Imam Hussein" },
    { hm: 1, hd: 10, cat: "religious", holiday: true, fa: "عاشورای حسینی", en: "Ashura" },
    { hm: 2, hd: 20, cat: "religious", holiday: true, fa: "اربعین حسینی", en: "Arbaeen" },
    { hm: 2, hd: 28, cat: "religious", holiday: true, fa: "رحلت پیامبر اکرم (ص) و شهادت امام حسن (ع)", en: "Demise of Prophet Muhammad & Martyrdom of Imam Hassan" },
    { hm: 2, hd: 30, cat: "religious", holiday: true, fa: "شهادت امام رضا (ع)", en: "Martyrdom of Imam Reza" },
    { hm: 3, hd: 8, cat: "religious", holiday: true, fa: "شهادت امام حسن عسکری (ع)", en: "Martyrdom of Imam Hassan al-Askari" },
    { hm: 3, hd: 17, cat: "religious", holiday: true, fa: "میلاد پیامبر اکرم (ص) و امام صادق (ع)", en: "Birthday of Prophet Muhammad & Imam Sadiq" },
    { hm: 6, hd: 3, cat: "religious", holiday: true, fa: "شهادت حضرت فاطمه زهرا (س)", en: "Martyrdom of Fatima al-Zahra" },
    { hm: 7, hd: 13, cat: "religious", holiday: true, fa: "ولادت امام علی (ع) و روز پدر", en: "Birth of Imam Ali / Father's Day" },
    { hm: 7, hd: 27, cat: "religious", holiday: true, fa: "مبعث رسول اکرم (ص)", en: "Mab'ath of Prophet Muhammad" },
    { hm: 8, hd: 15, cat: "religious", holiday: true, fa: "ولادت حضرت مهدی (عج) / نیمه شعبان", en: "Birth of Imam Mahdi / Mid-Sha'ban" },
    { hm: 9, hd: 21, cat: "religious", holiday: true, fa: "شهادت امام علی (ع)", en: "Martyrdom of Imam Ali" },
    { hm: 10, hd: 1, cat: "religious", holiday: true, fa: "عید سعید فطر", en: "Eid al-Fitr" },
    { hm: 10, hd: 2, cat: "religious", holiday: true, fa: "تعطیل به مناسبت عید فطر", en: "Eid al-Fitr Holiday" },
    { hm: 10, hd: 25, cat: "religious", holiday: true, fa: "شهادت امام جعفر صادق (ع)", en: "Martyrdom of Imam Sadiq" },
    { hm: 12, hd: 10, cat: "religious", holiday: true, fa: "عید سعید قربان", en: "Eid al-Adha" },
    { hm: 12, hd: 18, cat: "religious", holiday: true, fa: "عید سعید غدیر خم", en: "Eid al-Ghadir" },
  ];

  // International days (Gregorian-based, optional)
  const STATIC_INTL_EVENTS = [
    { gm: 1, gd: 1, cat: "international", fa: "سال نو میلادی", en: "Gregorian New Year" },
    { gm: 3, gd: 8, cat: "international", fa: "روز جهانی زن", en: "International Women's Day" },
    { gm: 4, gd: 22, cat: "international", fa: "روز جهانی زمین", en: "Earth Day" },
    { gm: 5, gd: 1, cat: "international", fa: "روز جهانی کارگر", en: "International Workers' Day" },
    { gm: 12, gd: 25, cat: "international", fa: "کریسمس", en: "Christmas" },
  ];

  // Project Hijri event onto a Jalali year (returns [jy, jm, jd] or null)
  function projectHijriToJalali(jYear, hm, hd) {
    // Try the two Hijri years that could overlap with this Jalali year
    const candidates = [];
    for (let probeJm = 1; probeJm <= 12; probeJm++) {
      const [gy, gm, gd] = jalaliToGregorian(jYear, probeJm, 1);
      const [hy] = gregorianToHijri(gy, gm, gd);
      candidates.push(hy);
    }
    const hijriYears = [...new Set(candidates)];
    for (const hy of hijriYears) {
      // approximate Gregorian date for this hy/hm/hd by binary search on Julian day
      // simple approach: walk Jalali year day-by-day looking for matching hijri
      // we use a coarse approach: estimate by Gregorian conversion of Hijri using inverse
      // Iterate Jalali year and find first day matching
      for (let jm = 1; jm <= 12; jm++) {
        const daysInMonth = jm <= 6 ? 31 : (jm <= 11 ? 30 : (isJalaliLeap(jYear) ? 30 : 29));
        for (let jd = 1; jd <= daysInMonth; jd++) {
          const [gy, gm, gd] = jalaliToGregorian(jYear, jm, jd);
          const [chy, chm, chd] = gregorianToHijri(gy, gm, gd);
          if (chy === hy && chm === hm && chd === hd) return [jYear, jm, jd];
        }
      }
    }
    return null;
  }
  function isJalaliLeap(jy) {
    const breaks = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178];
    let jp = breaks[0], jump = 0, leap;
    for (let j = 1; j < breaks.length; j++) {
      const jm = breaks[j];
      jump = jm - jp;
      if (jy < jm) break;
      jp = jm;
    }
    let n = jy - jp;
    if (n < jump) {
      if (jump - n < 6) n = n - jump + Math.trunc((jump + 4) / 33) * 33;
      leap = ((((n + 1) % 33) - 1) % 4);
      if (leap === -1) leap = 4;
    } else leap = 0;
    return leap === 0;
  }

  // Project Gregorian event onto a Jalali year
  function projectGregorianToJalali(jYear, gm, gd) {
    // Try gy = jYear+621 and jYear+622
    for (const gy of [jYear + 621, jYear + 622]) {
      const [jy, jm, jd] = gregorianToJalali(gy, gm, gd);
      if (jy === jYear) return [jy, jm, jd];
    }
    return null;
  }

  function getYearEvents(jYear) {
    const out = [];
    for (const e of STATIC_JALALI_EVENTS) {
      out.push({ jy: jYear, jm: e.jm, jd: e.jd, cat: e.cat, holiday: !!e.holiday, fa: e.fa, en: e.en });
    }
    for (const e of STATIC_HIJRI_EVENTS) {
      const p = projectHijriToJalali(jYear, e.hm, e.hd);
      if (p) out.push({ jy: p[0], jm: p[1], jd: p[2], cat: e.cat, holiday: !!e.holiday, fa: e.fa, en: e.en, lunar: true });
    }
    for (const e of STATIC_INTL_EVENTS) {
      const p = projectGregorianToJalali(jYear, e.gm, e.gd);
      if (p) out.push({ jy: p[0], jm: p[1], jd: p[2], cat: e.cat, holiday: false, fa: e.fa, en: e.en, gregorian: true });
    }
    return out;
  }

  // Pre-compute events for previous 2y, current, next 5y once on first access
  let CACHE = null;
  function ensureCache() {
    if (CACHE) return CACHE;
    const now = new Date();
    const [tjy] = gregorianToJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
    CACHE = {};
    for (let y = tjy - 2; y <= tjy + 5; y++) CACHE[y] = getYearEvents(y);
    // Persist to localStorage for offline
    try { localStorage.setItem("codeisa.calendarCache", JSON.stringify({ tjy, cache: CACHE })); } catch (e) {}
    return CACHE;
  }
  function loadCacheFromDisk() {
    try {
      const raw = localStorage.getItem("codeisa.calendarCache");
      if (raw) { const parsed = JSON.parse(raw); CACHE = parsed.cache || null; }
    } catch (e) {}
  }
  loadCacheFromDisk();

  function eventsForJalali(jy, jm, jd) {
    ensureCache();
    const yr = CACHE[jy] || getYearEvents(jy);
    return yr.filter(e => e.jm === jm && e.jd === jd);
  }
  function todayInfo() {
    const now = new Date();
    const [jy, jm, jd] = gregorianToJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
    const [hy, hm, hd] = gregorianToHijri(now.getFullYear(), now.getMonth() + 1, now.getDate());
    const weekdayIdx = (now.getDay() + 1) % 7; // 0=Saturday
    const wdFa = ["شنبه","یکشنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه","جمعه"][weekdayIdx];
    const wdEn = ["Saturday","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday"][weekdayIdx];
    let season = jm <= 3 ? ["بهار","Spring"] : jm <= 6 ? ["تابستان","Summer"] : jm <= 9 ? ["پاییز","Autumn"] : ["زمستان","Winter"];
    return {
      fa: { y: jy, m: jm, d: jd },
      gr: { y: now.getFullYear(), m: now.getMonth()+1, d: now.getDate() },
      hj: { y: hy, m: hm, d: hd },
      weekday: { fa: wdFa, en: wdEn },
      season: { fa: season[0], en: season[1] },
      todayEvents: eventsForJalali(jy, jm, jd),
    };
  }
  function nextHoliday() {
    ensureCache();
    const t = todayInfo();
    let bestDays = Infinity, bestEvent = null;
    for (const y of Object.keys(CACHE)) {
      for (const e of CACHE[y]) {
        if (!e.holiday) continue;
        const [gy, gm, gd] = jalaliToGregorian(e.jy, e.jm, e.jd);
        const eventDate = new Date(gy, gm-1, gd);
        const now = new Date();
        const diff = Math.ceil((eventDate - now) / (1000*60*60*24));
        if (diff > 0 && diff < bestDays) { bestDays = diff; bestEvent = e; }
      }
    }
    return { event: bestEvent, daysUntil: bestEvent ? bestDays : null };
  }
  function search(query) {
    ensureCache();
    const q = (query || "").trim().toLowerCase();
    if (!q) return [];
    const out = [];
    for (const y of Object.keys(CACHE)) {
      for (const e of CACHE[y]) {
        if ((e.fa && e.fa.toLowerCase().includes(q)) || (e.en && e.en.toLowerCase().includes(q))) out.push(e);
      }
    }
    return out.slice(0, 50);
  }
  function filterCategory(cat) {
    ensureCache();
    const out = [];
    for (const y of Object.keys(CACHE)) for (const e of CACHE[y]) if (e.cat === cat || cat === "all") out.push(e);
    return out;
  }

  // ---------- Minimal mountable UI ----------
  function mount(rootId) {
    const root = document.getElementById(rootId);
    if (!root) return;
    const lang = (window.codeisaI18n?.getLanguage?.() || "fa");
    const isFa = lang === "fa";
    const info = todayInfo();
    const next = nextHoliday();
    const evToday = info.todayEvents.map(e => isFa ? e.fa : e.en).join(" • ") || (isFa ? "بدون رویداد" : "No events");

    root.innerHTML = `
      <div class="codeisa-cal-pro" style="display:grid;gap:14px;padding:14px;border-radius:14px;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);">
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;">
          <div style="padding:12px;border-radius:10px;background:linear-gradient(135deg,#4f8cff22,#8b5cf622);">
            <div style="font-size:11px;opacity:.7;">${isFa ? "تاریخ شمسی" : "Persian"}</div>
            <div style="font-size:20px;font-weight:600;">${info.fa.y}/${info.fa.m}/${info.fa.d}</div>
            <div style="font-size:12px;opacity:.8;">${isFa ? info.weekday.fa : info.weekday.en} — ${isFa ? info.season.fa : info.season.en}</div>
          </div>
          <div style="padding:12px;border-radius:10px;background:linear-gradient(135deg,#10b98122,#4f8cff22);">
            <div style="font-size:11px;opacity:.7;">${isFa ? "تاریخ میلادی" : "Gregorian"}</div>
            <div style="font-size:20px;font-weight:600;">${info.gr.y}-${String(info.gr.m).padStart(2,"0")}-${String(info.gr.d).padStart(2,"0")}</div>
          </div>
          <div style="padding:12px;border-radius:10px;background:linear-gradient(135deg,#f59e0b22,#ec489922);">
            <div style="font-size:11px;opacity:.7;">${isFa ? "تاریخ هجری قمری" : "Hijri"}</div>
            <div style="font-size:20px;font-weight:600;">${info.hj.y}/${info.hj.m}/${info.hj.d}</div>
          </div>
        </div>
        <div style="padding:12px;border-radius:10px;background:rgba(255,255,255,0.04);">
          <div style="font-size:12px;opacity:.7;margin-bottom:6px;">${isFa ? "رویدادهای امروز" : "Today's events"}</div>
          <div style="font-size:14px;">${evToday}</div>
        </div>
        ${next.event ? `
        <div style="padding:12px;border-radius:10px;background:linear-gradient(135deg,#8b5cf622,#ec489922);">
          <div style="font-size:12px;opacity:.7;">${isFa ? "تعطیلی رسمی بعدی" : "Next official holiday"}</div>
          <div style="font-size:16px;font-weight:600;margin-top:2px;">${isFa ? next.event.fa : next.event.en}</div>
          <div style="font-size:12px;opacity:.85;margin-top:2px;">${next.event.jy}/${next.event.jm}/${next.event.jd} — ${next.daysUntil} ${isFa ? "روز دیگر" : "days remaining"}</div>
        </div>` : ""}
        <input id="codeisa-cal-search" placeholder="${isFa ? "جستجوی رویداد یا تعطیلی…" : "Search events or holidays…"}" style="padding:10px;border-radius:10px;border:1px solid rgba(255,255,255,0.12);background:rgba(0,0,0,0.2);color:inherit;">
        <div id="codeisa-cal-search-results" style="display:grid;gap:6px;"></div>
      </div>`;
    const inp = root.querySelector("#codeisa-cal-search");
    const res = root.querySelector("#codeisa-cal-search-results");
    inp.addEventListener("input", () => {
      const list = search(inp.value);
      res.innerHTML = list.map(e =>
        `<div style="padding:8px 10px;border-radius:8px;background:rgba(255,255,255,0.04);font-size:13px;">
          <strong>${isFa ? e.fa : e.en}</strong>
          <span style="opacity:.6;margin-${isFa?"right":"left"}:8px;">${e.jy}/${e.jm}/${e.jd}</span>
        </div>`).join("") || `<div style="opacity:.6;font-size:12px;">${isFa ? "نتیجه‌ای یافت نشد" : "No results"}</div>`;
    });
  }

  window.codeisaCalendarPro = {
    todayInfo, eventsForJalali, nextHoliday, search,
    filter: filterCategory, mount,
    jalaliToGregorian, gregorianToJalali, gregorianToHijri,
  };

  // Auto-mount if a host element exists
  document.addEventListener("DOMContentLoaded", () => {
    ensureCache();
    const host = document.getElementById("codeisa-calendar-pro");
    if (host) mount("codeisa-calendar-pro");
  });
})();
