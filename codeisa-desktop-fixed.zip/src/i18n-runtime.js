/* ============================================================================
 * Codeisa — Runtime i18n Overlay
 * ----------------------------------------------------------------------------
 * Non-invasive localization layer. Loads the original application untouched
 * and translates the DOM via a MutationObserver + text-node walker driven by
 * the bundled locale tables (locales/fa.json, locales/en.json).
 *
 *  - Persian mode: no transformation (original text is already Persian)
 *  - English mode: every Persian text-node is looked up in the translation
 *                  map; matches are replaced; remaining Persian fragments
 *                  are reported on `window.codeisaI18nMissing` and to the
 *                  Tauri backend for the audit dashboard.
 * ============================================================================ */
(function () {
  "use strict";

  const STORAGE_KEY = "codeisa.lang";
  const PERSIAN_RE = /[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]/;

  const state = {
    lang: localStorage.getItem(STORAGE_KEY) || "fa",
    fa: {},
    en: {},
    reverse: {}, // Persian text -> English translation
    observer: null,
    missing: new Set(),
  };

  async function loadLocales() {
    try {
      const [fa, en] = await Promise.all([
        fetch("./locales/fa.json").then((r) => r.json()),
        fetch("./locales/en.json").then((r) => r.json()),
      ]);
      state.fa = fa;
      state.en = en;
      // Build reverse map: Persian original -> English translation
      for (const key of Object.keys(fa)) {
        const persianSrc = (fa[key] || "").trim();
        const englishDst = (en[key] || "").trim();
        if (!persianSrc) continue;
        state.reverse[persianSrc] = englishDst;
      }
    } catch (err) {
      console.error("[i18n] failed to load locale files", err);
    }
  }

  function translateFragment(text) {
    if (!text || !PERSIAN_RE.test(text)) return text;
    if (state.lang !== "en") return text;

    // 1. Whole-string fast path
    const trimmed = text.trim();
    if (state.reverse[trimmed]) {
      const rep = state.reverse[trimmed];
      // Preserve surrounding whitespace
      const left = text.match(/^\s*/)[0];
      const right = text.match(/\s*$/)[0];
      return left + rep + right;
    }

    // 2. Token-level replacement for compound strings
    let out = text;
    // Sort longest-first so multi-word phrases match before sub-tokens
    const persianKeys = Object.keys(state.reverse).sort(
      (a, b) => b.length - a.length
    );
    for (const src of persianKeys) {
      if (src.length < 2) continue;
      if (out.includes(src)) {
        const dst = state.reverse[src];
        if (dst && dst !== src) out = out.split(src).join(dst);
      }
    }

    // 3. Anything still Persian -> record as missing
    if (PERSIAN_RE.test(out)) {
      state.missing.add(out.trim());
    }
    return out;
  }

  function translateNode(node) {
    if (!node) return;
    if (node.nodeType === Node.TEXT_NODE) {
      const original = node.nodeValue;
      const replaced = translateFragment(original);
      if (replaced !== original) node.nodeValue = replaced;
      return;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return;

    // Translate select attributes
    const ATTRS = ["title", "placeholder", "alt", "aria-label", "value"];
    for (const a of ATTRS) {
      if (!node.hasAttribute(a)) continue;
      // Skip <input type=text> value (user input)
      if (a === "value") {
        const t = (node.getAttribute("type") || "").toLowerCase();
        if (node.tagName === "INPUT" && t !== "button" && t !== "submit") continue;
      }
      const v = node.getAttribute(a);
      const nv = translateFragment(v);
      if (nv !== v) node.setAttribute(a, nv);
    }

    // Recurse children
    for (let i = 0; i < node.childNodes.length; i++) {
      translateNode(node.childNodes[i]);
    }
  }

  function applyLanguage() {
    document.documentElement.lang = state.lang === "fa" ? "fa" : "en";
    document.documentElement.dir = state.lang === "fa" ? "rtl" : "ltr";
    document.documentElement.setAttribute("data-codeisa-lang", state.lang);
    if (state.lang === "en") {
      translateNode(document.body);
    }
    // Notify other modules
    window.dispatchEvent(
      new CustomEvent("codeisa:languageChanged", { detail: { lang: state.lang } })
    );
    if (window.__TAURI__?.event?.emit) {
      window.__TAURI__.event.emit("codeisa://language-changed", state.lang);
    }
  }

  function startObserver() {
    if (state.observer) state.observer.disconnect();
    state.observer = new MutationObserver((mutations) => {
      if (state.lang !== "en") return;
      for (const m of mutations) {
        if (m.type === "childList") {
          m.addedNodes.forEach((n) => translateNode(n));
        } else if (m.type === "characterData") {
          translateNode(m.target);
        } else if (m.type === "attributes") {
          translateNode(m.target);
        }
      }
    });
    state.observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
      attributeFilter: ["title", "placeholder", "alt", "aria-label"],
    });
  }

  function setLanguage(lang) {
    if (lang !== "fa" && lang !== "en") return;
    if (state.lang === lang) return;
    state.lang = lang;
    localStorage.setItem(STORAGE_KEY, lang);
    if (lang === "fa") {
      // Soft reload to restore Persian originals (cheapest correctness path)
      location.reload();
      return;
    }
    applyLanguage();
  }

  function auditReport() {
    return {
      lang: state.lang,
      totalKeys: Object.keys(state.fa).length,
      missingAtRuntime: Array.from(state.missing),
      missingCount: state.missing.size,
    };
  }

  // Public API
  window.codeisaI18n = {
    setLanguage,
    getLanguage: () => state.lang,
    auditReport,
    translate: translateFragment,
    reload: async () => {
      await loadLocales();
      applyLanguage();
    },
  };

  // Boot
  document.addEventListener("DOMContentLoaded", async () => {
    await loadLocales();
    applyLanguage();
    startObserver();
  });
})();
